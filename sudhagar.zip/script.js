let user = document.getElementById('user');
let pass = document.getElementById('pass');
let temp_pass = generatePass();
const audio = new Audio('./siren-alert-96052.mp3');
console.log(temp_pass);

function check() {
    if (temp_pass === pass.value) {
        alert('login succeeded');
    } else {
        audio.play();
        alert('Invalid passcode!');
    }
}

async function process() {
    fetch('http://localhost:3000/call-node-function', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                pass: temp_pass
            })
        }).then(res => res.json()).then(data => console.log(data))
        .catch(err => console.error(err));
}

function generatePass() {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*_';
    let password = '';

    for (let i = 0; i < 12; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }

    return password;
}

function reset() {
    document.getElementById('user').value = "";
    document.getElementById('pass').value = "";
}